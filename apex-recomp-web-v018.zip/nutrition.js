/* APEX RECOMP nutrition: local diary, no invented food composition values. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.ApexNutrition=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const day=s=>/^\d{4}-\d{2}-\d{2}$/.test(s)&&!Number.isNaN(Date.parse(s+'T12:00:00Z'));
const number=(n,max)=>{const v=typeof n==='string'?n.trim().replace(',','.'):n;if(v===''||v===null||v===undefined||!Number.isFinite(Number(v))||Number(v)<0||Number(v)>max)throw Error('Cantidad nutricional no válida');return Number(v);};
function clean(item){if(!item||typeof item!=='object'||Array.isArray(item))throw Error('Comida no válida');const name=String(item.name||'').trim();if(!name||name.length>120)throw Error('Indica un nombre de comida válido');if(!day(item.date))throw Error('Fecha no válida');return {id:String(item.id||''),date:item.date,name,kcal:number(item.kcal,10000),protein:number(item.protein,1000),carbs:number(item.carbs,1500),fat:number(item.fat,1000),note:String(item.note||'').slice(0,500)};}
function totals(entries,date){return (entries||[]).filter(e=>e.date===date).reduce((r,e)=>{const x=clean(e);r.kcal+=x.kcal;r.protein+=x.protein;r.carbs+=x.carbs;r.fat+=x.fat;r.count++;return r;},{kcal:0,protein:0,carbs:0,fat:0,count:0});}
function add(entries,item){const cleanItem=clean(item);if(!cleanItem.id)throw Error('Falta el identificador');if((entries||[]).some(e=>e.id===cleanItem.id))throw Error('Comida duplicada');return [...(entries||[]),cleanItem];}
function remove(entries,id){return (entries||[]).filter(e=>e.id!==id);}
function planDays(start,days=7){if(!day(start)||!Number.isInteger(days)||days<1||days>30)throw Error('Plan no válido');const base=new Date(start+'T12:00:00Z');return Array.from({length:days},(_,i)=>{const d=new Date(base);d.setUTCDate(d.getUTCDate()+i);return {date:d.toISOString().slice(0,10),meals:[]};});}
return {clean,totals,add,remove,planDays};
});
