/* Validate an APEX RECOMP backup before it can replace or merge local data. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.ApexBackup=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const plain=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
function validate(data){
 if(!plain(data)||data.schema!=='apex-recomp/v1')throw Error('La copia no es de APEX RECOMP');
 if(!Array.isArray(data.sessions)||!plain(data.exercises))throw Error('Sesiones o catálogo de ejercicios inválidos');
 const ids=new Set();let sets=0;
 for(const session of data.sessions){
  if(!plain(session)||typeof session.id!=='string'||!session.id||ids.has(session.id)||!Array.isArray(session.exercises))throw Error('Sesión duplicada o inválida');
  ids.add(session.id);
  for(const exercise of session.exercises){
   if(!plain(exercise)||typeof exercise.name!=='string'||!Array.isArray(exercise.sets))throw Error('Ejercicio inválido');
   for(const set of exercise.sets){if(!plain(set))throw Error('Serie inválida');sets++;}
  }
 }
 if(data.nutritionDiary!==undefined&&!Array.isArray(data.nutritionDiary))throw Error('Diario nutricional inválido');
 if(data.weekPlan!==undefined&&!Array.isArray(data.weekPlan))throw Error('Plan semanal inválido');
 if(data.apexProfile!==undefined){if(!plain(data.apexProfile)||!plain(data.apexProfile.targets))throw Error('Perfil inválido');}
 return {sessions:ids.size,sets};
}
function merge(existing,incoming){
 validate(incoming);
 if(!existing)return JSON.parse(JSON.stringify(incoming));
 validate(existing);
 const output=JSON.parse(JSON.stringify(existing));
 const known=new Map(output.sessions.map(s=>[s.id,s]));
 for(const s of incoming.sessions){
  if(!known.has(s.id)){output.sessions.push(JSON.parse(JSON.stringify(s)));known.set(s.id,s);}
  else if(JSON.stringify(known.get(s.id))!==JSON.stringify(s))throw Error('Conflicto en sesión '+s.id+'; exporta las dos copias y revisa antes de importar');
 }
 for(const [id,e] of Object.entries(incoming.exercises)){
  if(!(id in output.exercises))output.exercises[id]=JSON.parse(JSON.stringify(e));
  else if(JSON.stringify(output.exercises[id])!==JSON.stringify(e))throw Error('Conflicto en el ejercicio '+id);
 }
 const entries=new Map((output.nutritionDiary||[]).map((e,i)=>[e.id||'sin-id-'+i,e]));
 for(const [i,e] of (incoming.nutritionDiary||[]).entries()){
  if(!plain(e))throw Error('Comida inválida');
  const id=e.id||'sin-id-'+i;
  if(!entries.has(id)){(output.nutritionDiary??=[]).push(JSON.parse(JSON.stringify(e)));entries.set(id,e);}
  else if(JSON.stringify(entries.get(id))!==JSON.stringify(e))throw Error('Conflicto en comida '+id);
 }
 if(incoming.weekPlan?.length){
  if(!output.weekPlan?.length)output.weekPlan=JSON.parse(JSON.stringify(incoming.weekPlan));
  else if(JSON.stringify(output.weekPlan)!==JSON.stringify(incoming.weekPlan))throw Error('Planes semanales diferentes: exporta una copia antes de continuar');
 }
 if(incoming.apexProfile){
  if(!output.apexProfile)output.apexProfile=JSON.parse(JSON.stringify(incoming.apexProfile));
  else if(JSON.stringify(output.apexProfile)!==JSON.stringify(incoming.apexProfile))throw Error('Perfiles diferentes: exporta ambas copias antes de importar');
 }
 validate(output);return output;
}
return {validate,merge};
});
