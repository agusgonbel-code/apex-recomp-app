/* Recetas orientativas: los macros son estimaciones, no análisis de laboratorio. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.ApexRecipes=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const data=[
['Avena con yogur y plátano','Desayuno',450,25,65,10,'60 g de avena;200 g de yogur natural;1 plátano','Mezcla la avena y el yogur. Añade el plátano en rodajas.'],
['Tostadas con huevo','Desayuno',410,24,35,18,'80 g de pan integral;2 huevos;tomate;5 g de aceite de oliva','Tuesta el pan, cocina los huevos y añade tomate.'],
['Batido de frutos rojos','Desayuno',320,24,40,7,'200 g de yogur alto en proteína;100 g de frutos rojos;1 plátano','Tritura todos los ingredientes hasta obtener una textura homogénea.'],
['Pollo con arroz y verduras','Comida',630,50,70,16,'160 g de pechuga de pollo;90 g de arroz en crudo;200 g de verduras;10 g de aceite','Cuece el arroz. Cocina el pollo y las verduras y sirve junto.'],
['Ensalada de garbanzos y atún','Comida',510,36,43,20,'180 g de garbanzos cocidos;1 lata de atún al natural;tomate;cebolla;10 g de aceite','Lava los garbanzos y mezcla con el resto de ingredientes.'],
['Pasta integral con pavo','Comida',610,46,75,13,'90 g de pasta integral en crudo;150 g de pavo;tomate triturado;aceite','Cuece la pasta y prepara una salsa con el pavo y tomate.'],
['Salmón con patata','Cena',580,39,46,25,'160 g de salmón;250 g de patata;verduras','Hornea el salmón y la patata. Acompaña con verduras.'],
['Tortilla de espinacas','Cena',360,28,10,23,'3 huevos;100 g de espinacas;40 g de queso fresco','Saltea las espinacas y cuaja la tortilla con el queso.'],
['Merluza con quinoa','Cena',490,42,48,12,'180 g de merluza;70 g de quinoa en crudo;verduras','Cuece la quinoa, cocina la merluza y añade verduras.'],
['Yogur con nueces y fruta','Merienda',290,18,24,14,'200 g de yogur natural;20 g de nueces;1 fruta','Sirve el yogur con la fruta cortada y las nueces.'],
['Sándwich de pavo','Merienda',340,28,39,8,'80 g de pan integral;100 g de pavo;tomate;hojas verdes','Monta el sándwich con los ingredientes.'],
['Hummus con zanahoria','Merienda',250,9,24,13,'100 g de hummus;150 g de zanahoria','Corta la zanahoria en bastones y sirve con hummus.']
].map((r,i)=>({id:'ar-'+(i+1),name:r[0],category:r[1],kcal:r[2],protein:r[3],carbs:r[4],fat:r[5],ingredients:r[6].split(';'),steps:r[7],estimated:true}));
function search(q='',category='Todas'){const term=String(q).toLocaleLowerCase('es');return data.filter(r=>(category==='Todas'||r.category===category)&&(r.name+' '+r.ingredients.join(' ')).toLocaleLowerCase('es').includes(term));}
function scale(recipe,servings=1){if(!recipe||!Number.isFinite(servings)||servings<=0||servings>10)throw Error('Raciones no válidas');return {kcal:recipe.kcal*servings,protein:recipe.protein*servings,carbs:recipe.carbs*servings,fat:recipe.fat*servings};}
return {catalog:data,search,scale};
});
