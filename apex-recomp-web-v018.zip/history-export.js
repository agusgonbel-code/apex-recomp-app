/* Local-only CSV export. Do not upload private history. */
(function(root){'use strict';
const columns=['Fecha','Sesión','Ejercicio','ID ejercicio','Músculo','Serie','Kg','Repeticiones','RIR','Completada'];
function cell(v){let s=String(v??'');if(/^[\s]*[=+@\-\t\r]/.test(s) && !/^\s*-?\d+(?:[.,]\d+)?\s*$/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}
function exportCSV(sessions){if(!Array.isArray(sessions))throw Error('Historial inválido');const rows=[columns];for(const session of sessions){if(!session||session.status==='active')continue;for(const ex of session.exercises||[]){let n=0;for(const set of ex.sets||[]){n++;rows.push([session.date,session.title,ex.name,ex.exerciseId||ex.canonical||'',ex.muscle||'',n,set.kg,set.reps,set.rir,set.done?'Sí':'No']);}}}return '\uFEFF'+rows.map(r=>r.map(cell).join(';')).join('\r\n')+'\r\n';}
const api={exportCSV,cell};if(typeof module==='object'&&module.exports)module.exports=api;root.ApexHistoryExport=api;
})(typeof globalThis!=='undefined'?globalThis:this);
