/* Profile and nutrition target helpers; no medical claims. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.ApexProfile=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const plain=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
function targets(raw){if(!plain(raw))throw Error('Objetivos inválidos');const fields={kcal:[0,10000],protein:[0,1000],carbs:[0,1500],fat:[0,1000]};const out={};for(const [k,[min,max]] of Object.entries(fields)){const v=raw[k];if(v===null||v===undefined||v===''){out[k]=null;continue;}const n=Number(String(v).replace(',','.'));if(!Number.isFinite(n)||n<min||n>max)throw Error('Objetivo fuera de rango: '+k);out[k]=n;}return out;}
function balance(totals,goal){const target=targets(goal);const out={};for(const k of Object.keys(target))out[k]=target[k]===null?null:Math.round((target[k]-Number(totals?.[k]||0))*10)/10;return out;}
function name(raw){const value=String(raw??'').trim();if(value.length>80)throw Error('Nombre demasiado largo');return value;}
function normalize(profile){if(!plain(profile))profile={};return {displayName:name(profile.displayName),targets:targets(profile.targets||{})};}
return {targets,balance,name,normalize};
});
