/* Conservative local persistence: never replace a valid primary with a broken snapshot. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.ApexStorage=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const valid=x=>x&&x.schema==='apex-recomp/v1'&&Array.isArray(x.sessions)&&x.exercises&&typeof x.exercises==='object'&&!Array.isArray(x.exercises);
function parse(raw){if(!raw)return null;try{const v=JSON.parse(raw);return valid(v)?v:null;}catch{return null;}}
function read(store,key){const main=parse(store.getItem(key));if(main)return {data:main,recovered:false};const recovery=parse(store.getItem(key+'-recovery'));return {data:recovery,recovered:!!recovery};}
function write(store,key,value){if(!valid(value))throw Error('Datos no válidos: guardado cancelado');const serialized=JSON.stringify(value),old=store.getItem(key);const current=parse(old);if(current){store.setItem(key+'-recovery',old);}try{store.setItem(key,serialized);if(!parse(store.getItem(key)))throw Error('El guardado no se pudo verificar');return true;}catch(e){if(current){try{store.setItem(key,old);}catch{}}throw e;}}
return {read,write,valid};
});
